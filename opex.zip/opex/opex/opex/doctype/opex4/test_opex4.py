# Copyright (c) 2022, opex and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestOpEx4(FrappeTestCase):
	pass
